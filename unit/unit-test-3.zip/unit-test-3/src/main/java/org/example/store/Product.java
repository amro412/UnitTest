package org.example.store;

import lombok.Data;

@Data
public class Product {
    private String name;
    private int price;
    private int quantity;
}
